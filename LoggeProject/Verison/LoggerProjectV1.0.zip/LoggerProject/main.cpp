/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Owner
 *
 * Created on February 28, 2021, 3:17 PM
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>
#include "InNOutClass.h"
using namespace std;

int main(int argc, char** argv) {
    string inOrOut;
    string ampm;
    int studentID,month,
            day,year,time,minute;
    vector<InNOutClass> loggingInVector;
    
    cout << "Are you signing in or out" << endl;
    cout << "type IN to sign in or OUT to sign out" << endl;
    cin >> inOrOut;
    
    if(inOrOut == "IN"){
        cout << "Please enter your student ID" << endl;
        cin >> studentID;
        
        cout << "Please enter the following MM/DD/YYYY " << endl;
        scanf("%d/%d/%d", &month, &day, &year);
        cout << month << "/" << day << "/" << year << endl;
        
        cout << "Please enter the following HH:MM" << endl;
        scanf("%d:%d", &time,&minute);
        cout <<"AM or PM" << endl;
        cin >> ampm;
        if(ampm == "AM"){
            cout << time << ":" << minute << " " << ampm << endl;
        }
        else{
            cout << time << ":" << minute << " " << ampm << endl;
        }
        InNOutClass logIN(studentID, month, day, year, time, minute);
        loggingInVector.push_back(logIN);
    }
    
    for(int i=0; i < loggingInVector.size(); i++){
        loggingInVector[i].getInfo();
    }
    
    
    return 0;
}

