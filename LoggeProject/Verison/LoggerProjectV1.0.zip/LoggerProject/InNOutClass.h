/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   InNOutClass.h
 * Author: Owner
 *
 * Created on March 1, 2021, 9:58 AM
 */

#ifndef INNOUTCLASS_H
#define INNOUTCLASS_H

class InNOutClass {
public:
    //Construcotr
    InNOutClass(int studentID, int month, int day, int year, int hour, int mintue);
    
    //Accessor
    int getID();
    int getMonth();
    int getDay();
    int getYear();
    int getHour();
    int getMintue();
    void getInfo();
    
    //Mutator
    int setID(int);
    int setMonth(int);
    int setDay(int);
    int setYear(int);
    int setHour(int);
    int setMintue(int);
    
    //Desconcturotor 
    virtual ~InNOutClass();
    
private:
    int studentID,month,
            day,year,hour,minute;
};


#endif /* INNOUTCLASS_H */

