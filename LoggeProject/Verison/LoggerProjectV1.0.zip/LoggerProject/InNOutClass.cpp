/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   InNOutClass.cpp
 * Author: Owner
 * 
 * Created on March 1, 2021, 9:58 AM
 */

#include "InNOutClass.h"
#include <iostream>
using namespace std;

InNOutClass::InNOutClass(int studentID, int month, int day, int year, int hour, int mintue) {
    this->studentID = studentID;
    this->month = month; 
    this->day = day;
    this->year = year;
    this->hour = hour;
    this->minute = mintue;
}

 //Accessor
int InNOutClass::getID() {
    return studentID;
}

int InNOutClass::getMonth(){
    return month;
}
int InNOutClass::getDay(){
    return day;
}
int InNOutClass::getYear(){
    return year;
}
int InNOutClass::getHour(){
    return hour;
}
int InNOutClass::getMintue(){
    return minute;
}

void InNOutClass::getInfo(){
    cout << "Student ID: " << studentID << endl;
    cout << "Month/Day/Year logged in: " << month << "/" << day << "/" << year << endl; 
    cout << "Time logged in: " << hour << ":" << minute << endl;
}
    
    //Mutator
int setID(int);
int setMonth(int);
int setDay(int);
int setYear(int);
int setHour(int);
int setMintue(int);


InNOutClass::~InNOutClass() {
    
}

