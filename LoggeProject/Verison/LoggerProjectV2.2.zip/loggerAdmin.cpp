#include "loggerAdmin.h"
#include "loggerClass.h"
#include "logHoursClass.h"
#include <iostream>
loggerAdmin::loggerAdmin(string adminName, string adminPass){
  this->adminName = adminName;
  this->adminPass = adminPass;
};

void loggerAdmin::setAdminName(string adminName){
  this->adminName = adminName;
};

void loggerAdmin::setAdminPass(string adminPass){
  this->adminPass = adminPass;
};

void loggerAdmin::setUserInfo(vector <logUser> passedInfo){
  this->userINFO = passedInfo;
}

string loggerAdmin::getAdminName(){
  return adminName;
};

string loggerAdmin::getAdminPass(){
  return adminPass;
};

void loggerAdmin::viewUsers(){
  cout << "Current Users" << endl;
  for(int i = 0; i < userINFO.size(); i++){
    cout << "Username: " << userINFO[i].getUsername() << endl;
    cout << "Password: " << userINFO[i].getUserPassword() << endl;
  }
};


vector <logUser> loggerAdmin::passUserInfo(){
  return userINFO;
};

void loggerAdmin::deleteUsers(){
  string userName;
  viewUsers();
  cout << "Type the username of the user which you would like to delete... " << endl;
  cin >> userName;
  for(int i = 0; i < userINFO.size(); i++){
      if(userName == userINFO[i].getUsername()){
        cout << "User has been found and deleted..." << endl;
        userINFO.erase(userINFO.begin() + i);
      }
  }
};

void loggerAdmin::editUsers(){
  string userName;
  string userPass;
  int studentID;
  viewUsers();
  cout << "Type the username of the user which you would like to edit... " << endl;
  for(int i = 0; i < userINFO.size(); i++){
      if(userName == userINFO[i].getUsername()){
        cout << "User has been found..." << endl;
        cout << "Please type the new username " << endl;
        cin >> userName;
        cout << "Please type the new password" << endl;
        cin >> userPass;
        cout << "Please type the new student ID" << endl;
        cin >> studentID;
        userINFO[i].setUsername(userName);
        userINFO[i].setUserPassword(userPass);
        userINFO[i].setStudentID(studentID);
      }
  }
};

void loggerAdmin::viewUserHours(){
  string userName;
  viewUsers();
  cout << "Type the username of the user which hours you'd like to view..." << endl;
  cin >> userName;
  for(int i = 0; i < userINFO.size(); i++){
      if(userName == userINFO[i].getUsername()){
        cout << "Hours logged in..." << endl;
        userINFO[i].viewHoursIn();
        cout << "Hours logged out..." << endl;
        userINFO[i].viewHoursOut();
      }
  }
};

void loggerAdmin::addUserHours(){
  string userName;
  viewUsers();
  int month, day, year, hour, minute;
  string ampm;
  cout << "Type the username of the user which hours you'd like to add to..." << endl;
  for(int i = 0; i < userINFO.size(); i++){
      if(userName == userINFO[i].getUsername()){
        cout << "Please enter the following MM/DD/YYYY " << endl;
        scanf("%d/%d/%d", &month, &day, &year);
        cout << "Please enter the following HH:MM" << endl;
        scanf("%d:%d", &hour,&minute);
        cout << "AM or PM" << endl;
        cin >> ampm;
          if(ampm == "AM"){
              ampm = "AM";
           }
          else if(ampm == "PM"){
              ampm = "PM";
           }
          cout << "Current time logged in" << endl;
          cout << month << "/" << day << "/" << year << " " << hour << ":" << minute << " " << ampm << endl;
          logHoursClass tempHoursIn(month,day,year,hour,minute,ampm);
          userINFO[i].setHoursIN(tempHoursIn);

          cout << "Please enter the following MM/DD/YYYY " << endl;
          scanf("%d/%d/%d", &month, &day, &year);
          cout << "Please enter the following HH:MM" << endl;
          scanf("%d:%d", &hour,&minute);
          cout << "AM or PM" << endl;
          cin >> ampm;
          if(ampm == "AM"){
              ampm = "AM";
          }
          else if(ampm == "PM"){
             ampm = "PM";
          }
          cout << "Current time logged out" << endl;
          cout << month << " " << day << " " << year << " " << hour << " " << minute << " " << ampm << endl;
          logHoursClass tempHoursOut(month, day, year, hour, minute, ampm);
          userINFO[i].setHoursOUT(tempHoursOut);
      }
  }
};

void loggerAdmin::deleteUserHours(){
  string userName;
  viewUserHours();
  vector <logHoursClass> tempHoursIn;
  vector <logHoursClass> tempHoursOut;
  int index;
  cout << "Type the username of the user which hours you'd like to delete..." << endl;
  cin >> userName;
  for(int i = 0; i < userINFO.size(); i++){
      if(userName == userINFO[i].getUsername()){
        userINFO[i].viewHoursIn();
        userINFO[i].viewHoursOut();
        tempHoursIn = userINFO[i].getHoursIn();
        tempHoursOut = userINFO[i].getHoursOut();
        cout << "Please type the line which you like deleted " << endl;
        cin >> index;
        for(int j = 0; j < tempHoursIn.size(); j++){
          if(index == j){
            tempHoursIn.erase(tempHoursIn.begin() + j);
          }
        }
        for(int r = 0; r < tempHoursOut.size(); r++){
          if(index == r){
            tempHoursOut.erase(tempHoursOut.begin() + r);
          }
        }
        userINFO[i].setListHoursOUT(tempHoursOut);
        userINFO[i].setListHoursIN(tempHoursIn);
      }
  }
};