#ifndef LOGGERUSER_H
#define LOGGERUSER_H
#include <string>

using namespace std;

class logUser{
    public:
        logUser(string, string, int);
        string getUsername();
        string getUserPassword();
        int getStudentID();
        
        void setUsername(string);
        void setUserPassword(string);
        void setStudentID(int);

        
    private:
        string userName, 
                userPassword;
        int studentID;    
};

#endif /* LOGGERUSER_H */