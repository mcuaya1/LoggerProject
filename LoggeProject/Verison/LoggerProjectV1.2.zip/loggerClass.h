#ifndef LOGGERCLASS_H
#define LOGGERCLASS_H
#include <string>
//#include <ctime>
#include <chrono>
#include "loggerUser.h"

using namespace std;

class loggerClass{
  public:
    loggerClass();
    loggerClass(std::chrono::time_point<std::chrono::system_clock> start);
    void storeUserInfo(logUser );
    void menu();
  private:
    std::chrono::time_point<std::chrono::system_clock> start;
};

#endif /* LOGGERUSER_H */