#ifndef LOGGERCLASS_H
#define LOGGERCLASS_H
#include <string>
#include <ctime>
#include "loggerUser.h"

using namespace std;

class loggerClass{
  public:
    loggerClass(string labSection, string labSectionHours);
    void storeUserInfo(logUser );
  private:
    time_t currentTime;
    string labSection;
    string labSectionHours;

};

#endif /* LOGGERUSER_H */