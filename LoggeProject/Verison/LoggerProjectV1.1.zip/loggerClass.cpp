#include "loggerClass.h"
#include "loggerUser.h"
#include <string>
#include <ctime>
#include <fstream>

void loggerClass::storeUserInfo(logUser user){
  ofstream userInfo;

  userInfo.open("userInfo", ios::app | ios::binary);
  userInfo.write((char*)&user, sizeof(logUser));
  userInfo.close();
};