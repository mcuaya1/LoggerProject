#include <iostream>
#include <string>
#include "loggerUser.h"
#include "loggerClass.h"
using namespace std;
int main() {
  string userName;
  string userPassword;
  int studentID;
  cout << "Enter userName " << endl;
  cin >> userName;
  cout << "Enter password" << endl;
  cin >> userPassword;
  cout << "Enter ID" << endl;
  cin >> studentID;

  logUser user1(userName,userPassword,studentID);
  cout << user1.getUsername() << endl;
  cout << user1.getUserPassword() << endl;
  cout << user1.getStudentID() << endl;

}