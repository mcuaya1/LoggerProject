#include "loggerClass.h"
#include "loggerUser.h"
#include <string>
#include <ctime>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;

loggerClass::loggerClass(){
  cout << "Welcome..." << endl;
};

loggerClass::loggerClass(std::chrono::time_point<std::chrono::system_clock> start){
  this->start = start;
  time_t starTime = std::chrono::system_clock::to_time_t(start);
  cout << ctime(&starTime) << endl;
};


void loggerClass::menu(){
  ifstream userInfo;
  logUser dummyUser("HOLDER", "HOLDER", 1234678);
  logUser tempUser("HOLDER", "HOLDER", 1234678);
  vector <logUser> tempVect;
  string userName;
  string userPassword;
  string line;
/*
  cout << "Please sign in" << endl;
  cout << "Username: ";
  cin >> userName;
  cout << "\n";
  cout << "Password: ";
  cin >> userPassword;
*/
  userInfo.open("userInfo.txt", ios::in);
  userInfo.seekg(0);
  userInfo.read((char*)&dummyUser, sizeof(dummyUser));
  //cout << dummyUser.getUsername() << endl;
  for( string line; getline(userInfo, line);){
    //cout << line << endl; 
    tempUser.setUsername(dummyUser.getUsername());
    tempUser.setUserPassword(dummyUser.getUserPassword());
    tempUser.setStudentID(dummyUser.getStudentID());
    cout << dummyUser.getUsername() << endl;
    cout << dummyUser.getUserPassword() << endl;
    cout << dummyUser.getStudentID() << endl;
    tempVect.push_back(tempUser);
    userInfo.read((char*)&dummyUser, sizeof(dummyUser));
  }
/*
  while(userInfo >> line){
        cout << line << endl;
        //cout << dummyUser.getUsername() << endl;
        //cout << dummyUser.getUserPassword() << endl;
        //cout << dummyUser.getStudentID() << endl;
        //userInfo.read((char*)&dummyUser, sizeof(dummyUser));
  }
  */
  userInfo.close();
  tempVect.swap(tempVect);
  cout << "TEST" << endl;

};


void loggerClass::storeUserInfo(logUser user){
  ofstream userInfo;
  //userInfo.open("userInfo.txt", ios::app);
  //userInfo << user.getUsername() << endl;
  //userInfo << user.getUserPassword() << endl;
  //userInfo << user.getStudentID() << endl;
  userInfo.write((char*)&user, sizeof(logUser));
  //userInfo << "\n";
  userInfo.close();
};