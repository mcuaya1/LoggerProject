#include <iostream>
#include <string>
#include "loggerUser.h"
#include "loggerClass.h"
using namespace std;
int main() {
  string userName;
  string userPassword;
  string labSection;
  string labSectionHours;
  loggerClass test;
  int studentID;

  //test.menu();
  //cout << "WORK" << endl;
/*
  cout << "Enter userName " << endl;
  cin >> userName;
  cout << "Enter password" << endl;
  cin >> userPassword;
  cout << "Enter ID" << endl;
  cin >> studentID;
*/

  logUser user1("Bob","Bob1234",1234567);
  logUser user2("Bob12","Bob123412",1234567);
  cout << user1.getUsername() << endl;
  cout << user1.getUserPassword() << endl;
  cout << user1.getStudentID() << endl;

  

  //cout << "Enter lab" << endl;
  //cin >> labSection;
  std::chrono::time_point<std::chrono::system_clock> start;
  start = std::chrono::system_clock::now();
  loggerClass logIN(start);

  //logIN.storeUserInfo(user1);
  //logIN.storeUserInfo(user2);
  //logIN.menu();
}