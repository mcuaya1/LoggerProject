#include "loggerClass.h"
#include "loggerUser.h"
#include <string>
#include <ctime>
#include <fstream>
#include <iostream>
#include <vector>
#include <sstream>
#include<algorithm>
using namespace std;

loggerClass::loggerClass(){
  cout << "Welcome..." << endl;
};

loggerClass::loggerClass(std::chrono::time_point<std::chrono::system_clock> start){
  this->start = start;
  time_t starTime = std::chrono::system_clock::to_time_t(start);
  cout << ctime(&starTime) << endl;
};


void loggerClass::menu(){
  ifstream userInfo;
  logUser dummyUser("HOLDER", "HOLDER", 1234678);
  logUser tempUser("HOLDER", "HOLDER", 1234678);
  //vector <string> tempVect;
  //vector <logUser> tempUsers;
  string userName;
  string userPassword;
  string content;
  int studentID;
  string line;
  int counter = 0;
/*
  cout << "Please sign in" << endl;
  cout << "Username: ";
  cin >> userName;
  cout << "\n";
  cout << "Password: ";
  cin >> userPassword;
*/
  userInfo.open("userInfo.bin", ios::in | ios::binary);
  userInfo.seekg(0);
  //userInfo.seekp(0);
  userInfo.read((char*)&dummyUser, sizeof(logUser));
  userInfo.clear();
  while(userInfo.eof() == false){
    cout << dummyUser.getUsername() << endl;
    cout << dummyUser.getUserPassword() << endl;
    cout << dummyUser.getStudentID() << endl;
    userInfo.read((char*)&dummyUser, sizeof(logUser));
  }
/*
  //cout << dummyUser.getUsername() << endl;
  for(string line; getline(userInfo, line);){
    //cout << line;
    //content = line + "\n";
    //cout << content;
    //tempVect.push_back(content);
    //tempVect[counter] = line + "\n";
    //counter++;
    //tempUser.setUsername(dummyUser.getUsername());
    //tempUser.setUserPassword(dummyUser.getUserPassword());
    //tempUser.setStudentID(dummyUser.getStudentID());
    cout << dummyUser.getUsername() << endl;
    cout << dummyUser.getUserPassword() << endl;
    cout << dummyUser.getStudentID() << endl;
    //tempVect.push_back(tempUser);
    userInfo.read((char*)&dummyUser, sizeof(logUser));
  }
*/  


/*
  for(int i = 0; i < tempVect.size(); i++){
    cout << tempVect[i];
  }
    cout << "END" << endl;
  for(int i = 0; i < tempVect.size(); i++){
    tempUser.setUsername(tempVect[i]);
    tempUser.setUserPassword(tempVect[i+1]);
    stringstream convert;(tempVect[i+2]);
    convert >> studentID;
    tempUser.setStudentID(studentID);
    tempUsers.push_back(tempUser);
  }

  for(int i = 0; i < tempUsers.size(); i++){
      cout << tempUsers[i].getUsername();
      cout << tempUsers[i].getUserPassword();
      cout << tempUsers[i].getStudentID();
  }
*/

/*
  while(userInfo >> line){
        cout << line << endl;
        //cout << dummyUser.getUsername() << endl;
        //cout << dummyUser.getUserPassword() << endl;
        //cout << dummyUser.getStudentID() << endl;
        //userInfo.read((char*)&dummyUser, sizeof(dummyUser));
  }
  */
  //userInfo.seekg(0);
  userInfo.close();
  //tempVect.swap(tempVect);
  cout << "TEST" << endl;

};


void loggerClass::storeUserInfo(logUser user){
  ofstream userInfo;
  userInfo.open("userInfo.bin", ios::app | ios::binary);
  userInfo.seekp(0);
  //userInfo << user.getUsername() + "\n";
  //userInfo << user.getUserPassword() + "\n";
  //userInfo << user.getStudentID();
  //userInfo << "\n"; 
  userInfo.write((char*)&user, sizeof(logUser));
  userInfo.close();
};