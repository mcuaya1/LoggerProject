#ifndef LOGGERUSER_H
#define LOGGERUSER_H
#include <string>
#include <vector>
#include "logHoursClass.h"
using namespace std;

class logUser{
    public:
        logUser(string, string, int);

        void storeHoursIN();
        void storeHoursOUT();


        string getUsername();
        string getUserPassword();
        int getStudentID();
        
        void setUsername(string);
        void setUserPassword(string);
        void setStudentID(int);

        //void setHoursIN(vector <logHoursClass>);
        void setHoursIN(logHoursClass);
        //void setHoursOUT(vector <logHoursClass>);
        void setHoursOUT(logHoursClass); 

        void viewHoursIn();
        void viewHoursOut();
        
    private:
        string userName, 
                userPassword;
        int studentID;
        vector <logHoursClass> user1HoursIN;
        vector <logHoursClass> user1HoursOUT;    
};

#endif /* LOGGERUSER_H */