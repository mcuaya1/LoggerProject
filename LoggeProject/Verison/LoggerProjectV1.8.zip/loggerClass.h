#ifndef LOGGERCLASS_H
#define LOGGERCLASS_H
#include <string>
//#include <ctime>
#include <chrono>
#include "loggerUser.h"
#include "logHoursClass.h"

using namespace std;

class loggerClass{
  public:
    loggerClass();

    void createAccount();
    void menu();
    bool checkUser(logUser);

    void storeUserInfo(logUser);
    void storeHoursIN(logHoursClass);
    void storeHoursOUT(logHoursClass);

    logUser currUser(logUser);
  private:
    //string startTime;
    //string endTime;
    //std::chrono::time_point<std::chrono::system_clock> start;
    vector <logUser> userINFO;
    vector <logHoursClass> userHoursIN;
    vector <logHoursClass> userHoursOUT;
    
};

#endif /* LOGGERUSER_H */