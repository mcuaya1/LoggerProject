#include "loggerClass.h"
#include "loggerUser.h"
#include <string>
#include <ctime>
#include <fstream>
#include <iostream>
#include <sstream>
#include <cstdlib>
using namespace std;

loggerClass::loggerClass(){
  cout << "Welcome..." << endl;
};

void loggerClass::createAccount(){
  string userName;
  string userPassword;
  int studentID;
  cout << "Enter a username: " << endl;
  cin >> userName;
  cout << "Enter a password: " << endl;
  cin >> userPassword;
  cout << "Etner your student ID " << endl;
  cin >> studentID;

  logUser newUser(userName,userPassword, studentID);
  storeUserInfo(newUser);
}

bool loggerClass::checkUser(logUser tempUser){
  bool flagCheck = false;
  for(int i = 0; i < userINFO.size(); i++){
    if(tempUser.getUsername() == userINFO[i].getUsername() && tempUser.getUserPassword() == userINFO[i].getUserPassword()){
        flagCheck = true;
    } 
  }
  return flagCheck;

};

logUser loggerClass::currUser(logUser currUser){
  logUser tempUser("TEMP", "TEMP", 12345678);
  for(int i = 0; i < userINFO.size(); i++){
    if(currUser.getUsername() == userINFO[i].getUsername() && currUser.getUserPassword() == userINFO[i].getUserPassword()){
      tempUser.setUsername(userINFO[i].getUsername());
      tempUser.setUserPassword(userINFO[i].getUserPassword());
      tempUser.setStudentID(userINFO[i].getStudentID());
    }
  }
  return tempUser;
}

void loggerClass::menu(){
  //ifstream userInfo;
  //logUser dummyUser("HOLDER", "HOLDER", 1234678);
  //logUser *ptr; 
  //ptr = &dummyUser;
  logUser tempUser("HOLDER", "HOLDER", 1234678);
  //vector <string> tempVect;
  //vector <logUser> tempUsers;
  string userName;
  string userPassword;
  string labSection;

  int month;
  int day;
  int year;
  int hour;
  int mintue;
  string ampm;
   
  char yesOrNo;
  char signInOrNot;
  int flagCheck;
  int inOrOutCheck;
  //string content;
  //int studentID;
  //string line;
  //int counter = 0;

  do{
    cout << "Would you like to sign in or exit the program..." << endl;
    cout << "Type 'Y ' to sign in or type 'X' to exit the program..." << endl;
    cin >> signInOrNot;
    if(signInOrNot == 'Y'){
      cout << "Username: ";
      cin >> userName;
      cout << "Password: ";
      cin >> userPassword;
      tempUser.setUsername(userName);
      tempUser.setUserPassword(userPassword);
    }
    else if(signInOrNot == 'X'){
        yesOrNo = 'X';
    }
    
    if(checkUser(tempUser) == true){
      tempUser = currUser(tempUser);
      cout << "Account found..." << endl;
      cout << "Welcome " << userName << endl;
      do{
          cout << "What would you like to do? " << endl;
          cout << "1) Choose a lab section and log hours in or out... " << endl;
          cout << "2) Sign out and exit the program..." << endl;
          cout << "3) View hours logged for a labe section..." << endl;
          cin >> flagCheck;
          if( flagCheck == 1){
            cout << "Please enter the Lab section you would like to log hours... " << endl;
            cin >> labSection;
            cout << "Are you logging hours in or out? " << endl;
            cout << "Type 1 to log hours in or type 2 to log hours out " << endl;
            cin >> inOrOutCheck;
            if(inOrOutCheck == 1){
              cout << "Please enter the following MM/DD/YYYY " << endl;
              scanf("%d/%d/%d", &month, &day, &year);
              cout << "Please enter the following HH:MM" << endl;
              scanf("%d:%d", &hour,&mintue);
              cout << "AM or PM" << endl;
              cin >> ampm;
                if(ampm == "AM"){
                    ampm = "AM";
                }
                else if(ampm == "PM"){
                    ampm = "PM";
                }
              cout << "Current time logged in" << endl;
              cout << month << "/" << day << "/" << year << " " << hour << ":" << mintue << " " << ampm << endl;
              logHoursClass tempHours(month, day, year, hour, mintue, ampm);
              tempUser.setHoursIN(tempHours);
              }
              else if(inOrOutCheck == 2){
              cout << "Please enter the following MM/DD/YYYY " << endl;
              scanf("%d/%d/%d", &month, &day, &year);
              cout << "Please enter the following HH:MM" << endl;
              scanf("%d:%d", &hour,&mintue);
              cout << "AM or PM" << endl;
              cin >> ampm;
                if(ampm == "AM"){
                    ampm = "AM";
                }
                else if(ampm == "PM"){
                    ampm = "PM";
                }
                cout << "Current time logged out" << endl;
                cout << month << " " << day << " " << year << " " << hour << " " << mintue << " " << ampm << endl;
                logHoursClass tempHours(month, day, year, hour, mintue, ampm);
                tempUser.setHoursOUT(tempHours);
              }
              
          }
          else if(flagCheck == 2){
            break;
          }
          else if(flagCheck == 3){
            tempUser.viewHoursIn();
            tempUser.viewHoursOut();
          }
      }while(yesOrNo != 'X');
    }
    else{
      cout << "No account was found..." << endl;
      cout << "Would you like to try again or make a new account? " << endl;
      cout << "Please type Y to try again or type C to create a new account or type X to exit the program " << endl;
      cin >> yesOrNo;
      if(yesOrNo == 'Y'){
        cout << "Username: ";
        cin >> userName;
        cout << "Password: ";
      }
      else if(yesOrNo == 'C'){
        createAccount();
      }
    }
  }while(yesOrNo != 'X');


/*
  cout << "Please sign in" << endl;
  cout << "Username: ";
  cin >> userName;
  cout << "\n";
  cout << "Password: ";
  cin >> userPassword;
*/
/*
  userInfo.open("userInfo.bin", ios::in | ios::binary);
  userInfo.seekg(0);
  //userInfo.seekp(0);
  userInfo.read((char*)&dummyUser, sizeof(logUser));
  if(!userInfo){
    cout << "ERROR" << endl;
    userInfo.clear();
    
  }
  
  while(userInfo.eof() == false){
    cout << dummyUser.getUsername() << endl;
    cout << dummyUser.getUserPassword() << endl;
    cout << dummyUser.getStudentID() << endl;
    cout << userInfo.gcount();
    cout << "\n";
    userInfo.read((char*)&dummyUser, sizeof(logUser));
    if(!userInfo){
      cout << userInfo.gcount();
      cout << "\n";
      userInfo.clear();
      userInfo.seekg(0);
      cout << "ERROR" << endl;
       userInfo.close();
      break;
    }
  }
  //userInfo.clear();
*/
/*
  //cout << dummyUser.getUsername() << endl;
  for(string line; getline(userInfo, line);){
    //cout << line;
    //content = line + "\n";
    //cout << content;
    //tempVect.push_back(content);
    //tempVect[counter] = line + "\n";
    //counter++;
    //tempUser.setUsername(dummyUser.getUsername());
    //tempUser.setUserPassword(dummyUser.getUserPassword());
    //tempUser.setStudentID(dummyUser.getStudentID());
    cout << dummyUser.getUsername() << endl;
    cout << dummyUser.getUserPassword() << endl;
    cout << dummyUser.getStudentID() << endl;
    //tempVect.push_back(tempUser);
    userInfo.read((char*)&dummyUser, sizeof(logUser));
  }
*/  


/*
  for(int i = 0; i < tempVect.size(); i++){
    cout << tempVect[i];
  }
    cout << "END" << endl;
  for(int i = 0; i < tempVect.size(); i++){
    tempUser.setUsername(tempVect[i]);
    tempUser.setUserPassword(tempVect[i+1]);
    stringstream convert;(tempVect[i+2]);
    convert >> studentID;
    tempUser.setStudentID(studentID);
    tempUsers.push_back(tempUser);
  }

  for(int i = 0; i < tempUsers.size(); i++){
      cout << tempUsers[i].getUsername();
      cout << tempUsers[i].getUserPassword();
      cout << tempUsers[i].getStudentID();
  }
*/

/*
  while(userInfo >> line){
        cout << line << endl;
        //cout << dummyUser.getUsername() << endl;
        //cout << dummyUser.getUserPassword() << endl;
        //cout << dummyUser.getStudentID() << endl;
        //userInfo.read((char*)&dummyUser, sizeof(dummyUser));
  }
  */
  //userInfo.seekg(0);
  //userInfo.close();
  //tempVect.swap(tempVect);
  cout << "TEST" << endl;

};


void loggerClass::storeUserInfo(logUser user){
  userINFO.push_back(user);
  //ofstream userInfo;
  //userInfo.open("userInfo.bin", ios::app | ios::binary);
  //userInfo.seekp(0);
  //userInfo << user.getUsername() + "\n";
  //userInfo << user.getUserPassword() + "\n";
  //userInfo << user.getStudentID();
  //userInfo << "\n"; 
  //userInfo.write((char*)&user, sizeof(logUser));
  //userInfo.clear();
  //userInfo.close();

};