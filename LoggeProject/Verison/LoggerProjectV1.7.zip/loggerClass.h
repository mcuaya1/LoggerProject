#ifndef LOGGERCLASS_H
#define LOGGERCLASS_H
#include <string>
//#include <ctime>
#include <chrono>
#include "loggerUser.h"

using namespace std;

class loggerClass{
  public:
    loggerClass();
    //loggerClass();
    void storeUserInfo(logUser );
    void createAccount();
    void menu();
    bool checkUser(string userName, string userPassword);
  private:
    string startTime;
    string endTime;
    //std::chrono::time_point<std::chrono::system_clock> start;
    vector <logUser> userINFO;
    
};

#endif /* LOGGERUSER_H */