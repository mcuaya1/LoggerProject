#include "loggerUser.h"
#include <string>
#include <chrono>
using namespace std;

//LOGUSER OBJECT
logUser::logUser(string userName, string userPassword, int studentID){
  this->userName = userName;
  this->userPassword = userPassword;
  this->studentID = studentID;
};

//SETTERS
void logUser::setUsername(string userName){
  this->userName = userName;
}

void logUser::setUserPassword(string userPassword){
  this->userPassword = userPassword;
}

void logUser::setStudentID(int studentID){
  this->studentID = studentID;
}

//ACCESSORS
string logUser::getUsername(){
  return userName; 
};

string logUser::getUserPassword(){
  return userPassword;
}

int logUser::getStudentID(){
  return studentID;
};
