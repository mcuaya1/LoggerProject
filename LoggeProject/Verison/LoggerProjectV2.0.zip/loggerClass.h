#ifndef LOGGERCLASS_H
#define LOGGERCLASS_H
#include <string>
//#include <ctime>
#include <chrono>
#include "loggerUser.h"
#include "logHoursClass.h"
#include "loggerAdmin.h"

using namespace std;

class loggerClass{
  public:
    loggerClass();

    void createAccount();
    void menu();
    void adminMenu(loggerAdmin);
    bool checkUser(logUser);
    bool checkAdmin(loggerAdmin);

    void storeUserInfo(logUser);
    void storeAdminInfo(loggerAdmin);
    void storeHoursIN(logHoursClass);
    void storeHoursOUT(logHoursClass);

    logUser currUser(logUser);
    loggerAdmin currAdmin(loggerAdmin);

    vector <logUser> passUsers();
  private:
    //string startTime;
    //string endTime;
    //std::chrono::time_point<std::chrono::system_clock> start;
    vector <logUser> userINFO;
    vector <loggerAdmin> adminINFO;
    //vector <logHoursClass> userHoursIN;
    //vector <logHoursClass> userHoursOUT;
    
};

#endif /* LOGGERUSER_H */